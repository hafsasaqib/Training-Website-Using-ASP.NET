﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Assig_3.Data
{
    public class Assig_3Context : DbContext
    {
        public Assig_3Context (DbContextOptions<Assig_3Context> options)
            : base(options)
        {
        }

        public DbSet<Assig_3.Models.Course> Course { get; set; }
    }
}
