﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Assig_3.Data;
using Assig_3.Models;

namespace Assig_3.Controllers
{
    public class CoursesController : Controller
    {
        private readonly Assig_3Context _context;

        public CoursesController(Assig_3Context context)
        {
            _context = context;
        }

        // Custom actions
       
        public IActionResult OnlineFreeCourse()
        {
            return View(_context.Course.Where(m => m.Type == "OnlineFreeCourse" ));
        }

        public IActionResult TrainingCentres()
        {
            return View(_context.Course.Where(m => m.Type == "TrainingCentres"));
        }

        public IActionResult UpcomingCourse()
        {
            return View(_context.Course.Where(m => m.Type == "PaidCourse"));
        }



        // GET: Courses
        // GET: Movies
        public async Task<IActionResult> Index(string searchString)
        {
            // Use LINQ to get list of genres.
            IQueryable<string> TypeQuery = from m in _context.Course
                                            orderby m.Type
                                            select m.Type;

            var courses = from m in _context.Course
                         select m;

            if (!string.IsNullOrEmpty(searchString))
            {
                courses = courses.Where(s => s.Type.Contains(searchString));
            }

            //if (!string.IsNullOrEmpty(coursesType))
            //{
             //   courses = courses.Where(x => x.Type == coursesType);
            //}

            var CoursesTypeVM = new CoursesTypeViewModel
            {
                Type = new SelectList(await TypeQuery.Distinct().ToListAsync()),
                Courses = await courses.ToListAsync()
            };

            return View(CoursesTypeVM);
        }
        
        [HttpPost]
        public string Index(string searchString, bool notUsed)
        {
            return "From [HttpPost]Index: filter on " + searchString;
        }

        // GET: Courses/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Course
                .FirstOrDefaultAsync(m => m.Id == id);
            if (course == null)
            {
                return NotFound();
            }

            return View(course);
        }

        // GET: Courses/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Courses/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Description,Type")] Course course)
        {
            if (ModelState.IsValid)
            {
                _context.Add(course);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(course);
        }

        // GET: Courses/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Course.FindAsync(id);
            if (course == null)
            {
                return NotFound();
            }
            return View(course);
        }

        // POST: Courses/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Description,Type")] Course course)
        {
            if (id != course.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(course);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CourseExists(course.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(course);
        }

        // GET: Courses/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var course = await _context.Course
                .FirstOrDefaultAsync(m => m.Id == id);
            if (course == null)
            {
                return NotFound();
            }

            return View(course);
        }

        // POST: Courses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var course = await _context.Course.FindAsync(id);
            _context.Course.Remove(course);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CourseExists(int id)
        {
            return _context.Course.Any(e => e.Id == id);
        }
    }
}
